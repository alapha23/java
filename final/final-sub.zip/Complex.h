#ifndef COMPLEX_H
#define COMPLEX_H

#include <iostream>

class Complex {
private:
	double real;
	double imag;
public:
	Complex(double real, double imag);
	double getReal();
	double getImag();
	void setReal(double real);
	void setImag(double imag);
	Complex add(Complex c);
	Complex multiply(Complex c);
	friend Complex operator+(const Complex c1, const Complex c2);
	friend Complex operator*(const Complex c1, const Complex c2);
	friend std::ostream& operator<<(std::ostream& out, Complex &o);
	friend std::istream& operator>>(std::istream& input, Complex &o);
};
#endif
