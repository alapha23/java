public class Ledger
{
	boolean txtype;
	int unitprice;
	double amount;
	Ledger next;

	/* You may modify if you want. */
	public Ledger(boolean t, int u, double a)
	{
		this.txtype = t;
		this.unitprice = u;
		this.amount = a;
		this.next = null;
	}

	/* Add more. */
}
