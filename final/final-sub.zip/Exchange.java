import java.util.Random;
import java.util.Scanner;

public class Exchange
{
	/* Random generator used in the class.*/
	public static Random rnd;

	/* Scanner used in the class. */
	public static Scanner sc;

	public void doRandom()
	{
		double prob = rnd.nextDouble();
		if(prob >= 0.75)
		{
			/* Increase. */
		}
		else if(prob <= 0.25)
		{
			/* Decrease. */
		}
		else
		{
			System.out.println("No change.");
		}
	}

	public static void main(String[] ar)
	{
		/* Initialize. */
		rnd = new Random();
		sc = new Scanner(System.in);
		Ledger ledger = new Ledger(false, rnd.nextInt(9901) + 100, 100);

		while(true)
		{
			System.out.print("Type command: ");
			String s = sc.nextLine();

			if(s.equalsIgnoreCase("e"))
			{
				break;
			}
		}
	}


}
